 <?php 
include('../db.php'); 
 $statement = $bdd->prepare(
   "UPDATE carrefour 
   SET  CoordonneeX = :CoordonneeX, CoordonneeY = :CoordonneeY , NomIntersection= :NomIntersection, Nbsorties= :Nbsorties
   WHERE Id_carrefour = :Id
   "
  );
  $statement->bindParam(':CoordonneeX',$_POST["CoordonneeX"] );
 $statement->bindParam(':Id',$_POST["Id_carrefour"] );
 $statement->bindParam(':CoordonneeY', $_POST["CoordonneeY"]);
 $statement->bindParam(':NomIntersection', $_POST["NomIntersection"]);
 $statement->bindParam(':Nbsorties', $_POST["Nbsorties"]);
  $statement = $statement->execute();
$statement = $bdd->prepare(
   "UPDATE grapheintersection
   SET  CoordonneeX = :CoordonneeX, CoordonneeY = :CoordonneeY , NomIntersection= :NomIntersection
   WHERE Id_intersection = :Id_intersection
   "
  );
 $statement->bindParam(':CoordonneeX',$_POST["CoordonneeX"] );
 $statement->bindParam(':Id_intersection',$_POST["Id_intersection"] );
 $statement->bindParam(':CoordonneeY', $_POST["CoordonneeY"]);
 $statement->bindParam(':NomIntersection', $_POST["NomIntersection"]);
  $statement = $statement->execute();
 header("location:aff.php");
  ?>