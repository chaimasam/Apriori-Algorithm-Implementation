<?php
 include('../db.php'); 

  
    $statement = $bdd->prepare("
   INSERT INTO grapheintersection (NomIntersection,CoordonneeX,CoordonneeY,Id_reseau) 
   VALUES ( :NomIntersection,:CoordonneeX, :CoordonneeY,:Id_reseau)
  ");
      $nv=$_POST["NomIntersection"];
      $cx=$_POST["CoordonneeX"];
      $cy= $_POST["CoordonneeY"];
      $idr=$_POST["Id_reseau"];
      $id=$_POST["Id_carrefour"];
      $nb=$_POST["Nbsorties"];
     $statement->bindParam(':NomIntersection', $_POST["NomIntersection"]);
     $statement->bindParam(':CoordonneeX',$_POST["CoordonneeX"] );
      $statement->bindParam(':CoordonneeY', $_POST["CoordonneeY"]);
     $statement->bindParam(':Id_reseau',$_POST["Id_reseau"] );
 $statement = $statement->execute();
    $donn =   $bdd->query("
    select max(Id_intersection) as id from grapheintersection
    ");
    $Id_intersection = $donn->fetch();
   
  $statement = $bdd->prepare("
   INSERT INTO carrefour (Id_intersection,Id_carrefour,Nbsorties,NomIntersection,CoordonneeX,CoordonneeY,Id_reseau) 
   VALUES (:Id_intersection,:Id_carrefour,:Nbsorties,:NomIntersection,:CoordonneeX, :CoordonneeY,:Id_reseau)
  ");

   
$statement->bindParam(':CoordonneeX',$cx);
 $statement->bindParam(':Id_carrefour',$id );
 $statement->bindParam(':Id_reseau',$idr );
 $statement->bindParam(':Id_intersection',$Id_intersection['id'] );
 $statement->bindParam(':CoordonneeY',$cy);
 $statement->bindParam(':NomIntersection',$nv);
 $statement->bindParam(':Nbsorties',$nb);
  $statement = $statement->execute();
//echo $id;
 header("location:aff.php");

  if(!empty($result))
  {
   echo 'Data Inserted';
  }
 

 

?>