<?php
include('../db.php'); 
$statement = $bdd->prepare(
  "SELECT * FROM boulevard ");
  $statement->execute();
 $result = $statement->fetchAll();
 ?>
<!DOCTYPE html>
<html>
<head>
    <title>gestion de Boulevard </title>
 
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

 <style type="text/css">
 	.box
   {
    width:1270px;
    padding:20px;
    background-color:#fff;
    border:1px solid #ccc;
    border-radius:5px;
    margin-top:25px;
   }
   input[type=text], input[type=password] {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
}

/* Set a style for all buttons */
#btn {
  background-color: #4CAF50;
  color: white;
   width: auto;
   margin-top: 0px;
margin-right: 0px;
margin-bottom: 0px;
margin-left: 0px;
  padding: 10px 18px;
  float: right;
  
}

button:hover {
  opacity: 0.8;
}

/* Extra styles for the cancel button */
.cancelbtn {
  margin-bottom: 10px;
  width: auto;
  padding: 10px 18px;
  background-color: #f44336;
  float: right;
}
#btn,
/* Center the image and position the close button */
.imgcontainer {
  text-align: center;
  margin: 24px 0 12px 0;
  position: relative;
}

img.avatar {
  width: 40%;
  border-radius: 50%;
}

.container {
  padding: 16px;
}

span.psw {
  float: right;
  padding-top: 16px;
}

/* The Modal (background) */
.modale {
  position: fixed; /* Stay in place */
  z-index: 1; /* Sit on top */
  left: 0;
  top: 0;
  width: 100%; /* Full width */
  height: 100%; /* Full height */
  overflow: auto; /* Enable scroll if needed */
  background-color: rgb(0,0,0); /* Fallback color */
  background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
  padding-top: 10px;
}

/* Modal Content/Box */
.modal-content {
  background-color: #fefefe;
  margin: 0% auto 15% auto; /* 5% from the top, 15% from the bottom and centered */
  border: 1px solid #888;
  width: 60%; /* Could be more or less, depending on screen size */
}

/* The Close Button (x) */
.close {
  position: absolute;
  right: 25px;
  top: 0;
  color: #000;
  font-size: 35px;
  font-weight: bold;
}
a:hover {
 color: white;
 text-decoration: none;
}
a {
 color: gray;
 text-decoration: none;
}
.close:hover,
.close:focus {
  color: red;
  cursor: pointer;
}

/* Add Zoom Animation */
.animate {
  -webkit-animation: animatezoom 0.6s;
  animation: animatezoom 0.6s
}

@-webkit-keyframes animatezoom {
  from {-webkit-transform: scale(0)} 
  to {-webkit-transform: scale(1)}
}
  
@keyframes animatezoom {
  from {transform: scale(0)} 
  to {transform: scale(1)}
}

/* Change styles for span and cancel button on extra small screens */
@media screen and (max-width: 300px) {
  span.psw {
     display: block;
     float: none;
  }
}
</s
</style>
 </style>
  </head>
<body>
	<div class="container box">
		<h1>Gestion des boulevards</h1>
		 <br />
    <div align="right">
     <button type="button" id="add_button" data-toggle="modal" data-target="#userModal" class="btn btn-info btn-lg">Add</button>
    </div>
    <br /><br />

    <div id="user_data_filter" class="dataTables_filter"><label>Search:<input type="search" class="form-control input-sm" placeholder="" aria-controls="user_data"></label></div>
	<div  class="container">

		<div id="userModal" class="modal fade">
 <div class="modal-dialog">
  <form method="post" id="user_form" action="insert.php" enctype="multipart/form-data">
   <div class="modal-content">
    <div class="modal-header">
     <button type="button" class="close" data-dismiss="modal">&times;</button>
     <h4 class="modal-title">Add Boulevard</h4>
    </div>
    <div class="modal-body">
     <label>Enter l'Id de Boulevard</label>
     <input type="number" name="Id_boulevard"  class="form-control" />
     <br />
      <label>Enter coordonneeX</label>
     <input type="number" name="CoordonneeX" id="CoordonneeX" class="form-control" />
     <br />
      <label>Enter coordonneeY</label>
     <input type="number" name="CoordonneeY" id="CoordonneeY" class="form-control" />
     <br />
      <label>Enter Nom_voie</label>
     <input type="text" name="Nom_voie" id="Nom_voie" class="form-control" />
     <br />
      <label>Enter Id_réseau</label>
     <input type="number" name="Id_reseau" id="Id_reseau" class="form-control" />
     <br />
     <span id="user_uploaded_image"></span>
    </div>
    <div class="modal-footer">
     <input type="hidden" name="user_id" id="user_id" />
     <input type="hidden" name="operation" id="operation" />
     <input type="submit" name="action" id="action" class="btn btn-success" value="Add" />
     <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
    </div>
   </div>
  </form>
 </div>
</div>
		<table class="table table-dark table-hover">
			    <thead>
			      <tr>
       <th width="35%">Id_voie</th>
       <th width="35%">Id_boulevard</th>
       <th width="35%">CoordonneeX</th>
       <th width="35%">CoordonneeY</th>
       <th width="35%">Nom_voie</th>
       <th width="35%">Id_reseau</th>
       <th width="10%">Edit</th>
       <th width="10%">Delete</th>
			      </tr>
			    </thead>
<?php
 foreach($result as $output)
 {
 	echo "<tr  class = \"ligne\">
				<td class = \"CNE\">
					".$output["Id_voie"]."
				</td>
				<td class = \"CIN\">
					".$output["Id_boulevard"]."
				</td>
				<td  class = \"naissace\">
					".$output["CoordonneeX"]."
				</td>
				<td class = \"gmail\">
					".$output["CoordonneeY"]."
				</td>
				<td class = \"tel\">
					".$output["Nom_voie"]."
				</td>
				<td class = \"adress\">
					".$output["Id_reseau"]."
				</td> 
				<td><button type=\"button\" name=\"update\" class=\"btn btn-warning btn-xs update\" style=\"width:auto;\" onclick=\"return update(".$output["Id_boulevard"].",".$output["Id_voie"].",".$output["Id_reseau"].",".$output["CoordonneeX"].",".$output["CoordonneeY"] .",'".$output["Nom_voie"]."');\" >Update</button></td>
				<td><button type=\"button\" name=\"delete\"  class=\"btn btn-warning btn-xs update\"  onclick=\"document.getElementById('id01').style.display='block'\" style=\"width:auto;\">delete</button></td></tr>";
 


 }
 ?>
</table></div>
</div> 
<button type="button" class="btn btn-outline-secondary"><a href="../reseau/aff.php">Réseau</a></button>
<button type="button" class="btn btn-outline-secondary"><a href="../voie/aff.php">Voie</a></button>
<button type="button" class="btn btn-outline-secondary"><a href="../piste/aff.php">Piste</a></button>
<button type="button" class="btn btn-outline-secondary"><a href="../rue/aff.php">Rue</a></button>
<button type="button" class="btn btn-outline-secondary" ><a href="../grapheintersection/aff.php">Graphe d'intersection</a></button>
<button type="button" class="btn btn-outline-secondary"><a href="../rondpoint/aff.php">Rond-point</a></button>
<button type="button" class="btn btn-outline-secondary"><a href="../carrefour/aff.php">carrefour</a></button>
<div class="result">
</div>


<script type="text/javascript">

function update(id1,id2,id4,coordonneeX,coordonneeY,nom){
	var html = "<div id=\"id01\" class=\"modale\">"
  
  +"<form class=\"modal-content animate\" method=\"POST\"action=\"modifier.php\">"
   +" <div class=\"imgcontainer\">"
     +" <span onclick=\"document.getElementById('id01').style.display='none'\" class=\"close\" title=\"Close Modal\">&times;</span>"
      +"<h1> update boulevard </h1>"
    +"</div>"

    +"	<div class=\"container\">"
     +"<input type=\"hidden\" name=\"Id_boulevard\" id=\"Id_boulevard\" value=\""+id1+"\" class=\"form-control\" />"
     +"<br />"
	  +"<input type=\"hidden\" name=\"Id_voie\" id=\"Id_boulevard\" value=\""+id2+"\" class=\"form-control\" />"
     +"<br />"
      +"<label>coordonneeY</label>"
     +"<input type=\"number\" name=\"CoordonneeX\" id=\"CoordonneeX\" value=\""+coordonneeX+"\" class=\"form-control\" />"
     +"<br />"
       +"<label>coordonneeY</label>"
     +"<input type=\"number\" name=\"CoordonneeY\" id=\"CoordonneeY\" value=\""+coordonneeY+"\" class=\"form-control\" />"
     +"<br />"
      +"<label>Nom_voie</label>"
     +"<input type=\"text\" name=\"Nom_voie\" id=\"Nom_voie\"  value=\""+nom+"\" class=\"form-control\" />"
     +"<br />"
      
     +"<span id=\"user_uploaded_image\"></span>"
	+"</div>"
	 +"<input type=\"hidden\" name=\"user_id\" id=\"user_id\" />"
     +"<input type=\"hidden\" name=\"operation\" id=\"operation\" />"
     
     +" <button id=\"btn\" type=\"submit\">UPDATE</button>"
      +"<button type=\"button\" onclick=\"document.getElementById('id01').style.display='none'\" class=\"cancelbtn\">Cancel</button>"
 
  +"</form>"
+"</div>"; 
document.getElementsByClassName('result')[0].innerHTML = html;
}




var modal = document.getElementById('id01');

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
</script>
</body>
</html>
