
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    
    <!-- Mobile Meta -->
    <meta name="viewport" content="width=device-width, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
    
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="author" content="">
    
    <!-- Site Icons -->
    <link rel="shortcut icon" href="../images/favicon.ico" type="image/x-icon" />
    <link rel="apple-touch-icon" href="../images/apple-touch-icon.png">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet"> 
    <link href="https://fonts.googleapis.com/css?family=Montserrat:300,400,500,600,700" rel="stylesheet"> 

    <!-- Custom & Default Styles -->
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/font-awesome.min.css">
    <link rel="stylesheet" href="../css/carousel.css">
    <link rel="stylesheet" href="../style.css">

  <link href="https://netdna.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css" rel="stylesheet">
  
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.1/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
  <link rel="stylesheet" href="policier.css">
  <script src="policier.js"></script>

</head>

<body>
<div class="container">
  <h1>Création de compte</h1>
  <hr />

  <div class="col-md-8">

    <form action="policier.php" method="POST" >

      <div class="form-input">
        <label for="nom">N.D'Accident</label>
        <input class="form-control" name="id_accident" type="text">
      </div>
      <br>
      <div class="form-input">
        <label for="cp">coordonnees</label>
        <div class="w3-row-padding">
             <div class="w3-half">
              <label class="w3-text-teal" >Latitude</label>
              <input name="X" class="w3-input w3-border" type="number" placeholder="Ex:31.6263427">
            </div>
            <div class="w3-half">
              <label class="w3-text-teal">Longitude</label>
                <input name = "Y"class="w3-input w3-border" type="number" placeholder="Ex:-7.990985">
            </div>    
      </div>
      <br>
         <div class="form-input">
        <label for="">type lieu</label>
        <input class="form-control" name="type_lieu" type="text">
      </div><br>
      <div>
      <div class="form-input">
        <label for="date">date</label>
        <input name="date" class="form-control"  placeholder="Min. 3 caractères" required="required" type="text" />
      </div><br>
      <div class="form-input">
        <label for="spaciale">Entité spatiale</label>
        <input name="spaciale" class="form-control"  placeholder="Min. 3 caractères" required="required" type="text" />
      </div><br>
      <div class="form-input">
        <label for="type">type</label>
        <input name="type" class="form-control"  placeholder="Min. 3 caractères" required="required" type="text" />
      </div><br>
      
      <div class="form-input">
        <label for="nombre">nombre de véhicules participés</label>
        <input id="nombre" class="form-control"  placeholder="0" required="required" min="1" max="5" type="number" onkeyup="myFunction()"/>
      </div>
      <div id="vehicule">

      </div>
      <div><br><b>Etat de Meteo</b><br> 
      <div class="form-input">
        <label for="etat">etat : </label>
        <input name="etatMet" class="form-control"  placeholder="" required="required"  type="text">
      </div>
      <br>
      <div class="form-input">
        <label for="temp">temperateur : </label>
        <input name="temp" class="form-control"  placeholder="0" required="required"  type="number">
      </div>
      <div class="form-input">
        <label for="vent">vent : </label>
        <input name="vent" class="form-control"  placeholder="0" required="required"  type="number">
      </div>
  
      <div class="form-input">
        <label for="name_voix">nom de voix : </label>
        <input namz="name_voix" class="form-control"  placeholder="0" required="required"  type="text">
      </div>
      <div class="form-input">
        <label for="etat_voix">etat de voix: </label>
        <input name="etat_voix" class="form-control"  placeholder="0" required="required"  type="text">
      </div>
      <br>     
      <button type="submit">
      Créer ce compte
    </button>

    </form>
    <br>
  </div>
</div>
</body>

</html>
</body>
</html>