<?php

$username = 'root';
$password = '';
try{
	$bdd = new PDO( 'mysql:host=localhost;dbname=database', $username, $password );
}catch(Exception $e){
	$e->getMessage();
}
$requet = $bdd->prepare("insert into `entite_spaciale` values (:place)");
$res = $requet->execute(array(':place' => $_POST['spaciale']));

$statement = $bdd->prepare("
INSERT INTO accident(id_accident, type, date_accident, place) 
VALUES (:id_accident, :type ,:date_accident, :place)
");
$result = $statement->execute(
array(
 ':id_accident' => trim($_POST['id_accident']),
 ':type' => trim($_POST["type"]),
 ':date_accident' => trim($_POST["date"]),
 ':place' => trim($_POST['spaciale'])
));
 $statement = $bdd->prepare("
	INSERT INTO vehicule( matricule, type, marque, etat_mecanique) 
	VALUES (:matricule ,:type_v, :marque, :etat_mecanique)
");
$result = $statement->execute(
array(
 ':matricule' => trim($_POST["matricule"]),
 ':type_v' => trim($_POST["type_v"]),
 ':marque' => trim($_POST['marque']),
 ':etat_mecanique' => trim($_POST['etat'])
));
 $statement = $bdd->prepare("
	INSERT INTO conducteur( CIN, nom, prenom, etat, type_permis, sexe, age) 
	VALUES (:cin ,:nom, :prenom, :etat_cond,:permis,:sexe,:age)
");

$result = $statement->execute(
array(
 ':cin' => trim($_POST["cin"]),
 ':nom' => trim($_POST["nom"]),
 ':prenom' => trim($_POST['prenom']),
 ':etat_cond' => trim($_POST['etat_cond']),
 ':permis' => trim($_POST['permis']),
 ':sexe' => trim($_POST['Gendre']),
 ':age' => trim($_POST['age'])
));
$statement = $bdd->prepare("
	INSERT INTO meteo( etat, temperateur, vent) 
	VALUES (:etatMet, :temp, :vent)
");

$result = $statement->execute(
array(
 ':etatMet' => trim($_POST['etatMet']),
 ':temp' => trim($_POST["temp"]),
 ':vent' => trim($_POST['vent'])
));
$statement = $bdd->prepare("
	INSERT INTO lieu_accident( nom, CoordonnerX, CoordonnerY,type) 
	VALUES (:nom, :X, :Y, :type_lieu)
");

$result = $statement->execute(
array(
 ':nom' => trim($_POST['nom']),
 ':X' => trim($_POST["X"]),
 ':Y' => trim($_POST['Y']),
 ':type_lieu' => trim($_POST['type_lieu'])
));
$statement = $bdd->prepare("
	INSERT INTO accidenter( matricule, CoordonnerX, CoordonnerY,id_accident,etat,temperateur,vent) 
	VALUES (:matricule, :X, :Y, :id_accident, :etatMet, :temp, :vent)
");

$result = $statement->execute(
array(
 'matricule' => trim($_POST['matricule']),
 ':X' => trim($_POST["X"]),
 ':Y' => trim($_POST['Y']),
 ':id_accident' => trim($_POST['id_accident']),
 ':etatMet' => trim($_POST['etatMet']),
 ':temp' => trim($_POST['temp']),
 ':vent' => trim($_POST['vent'])
));
$statement = $bdd->prepare("
	INSERT INTO conduire( CIN, matricule) 
	VALUES (cin,matricule)
");

$result = $statement->execute(
array(
 'matricule' => trim($_POST['matricule']),
 'cin' => trim($_POST['matricule'])
));
?>