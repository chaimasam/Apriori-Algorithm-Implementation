<?php

session_start();
$exist =false;
	if( isset($_POST["nom"]) && isset($_POST["pwd"]) isset($_POST['type']))
	{
		$nom=$_POST["nom"];
		$code=$_POST["pwd"];
		$code = md5($code);

		if(!empty($nom) && !empty($code) )
		{

			
				$selected_val = $_POST['type'];  // Storing Selected Value In Variable
			
			if($selected_val == "admin")
				$f=fopen("admin.csv","r") ;
			else
		    	$f=fopen("user.csv","r") ;

				while(!feof($f))
				{
				
					$user = fgetcsv($f);
					if($user[0] == $nom && $user[1] == $code){
							$_SESSION['uname']=$nom;
						    $_SESSION['pword']=$code;
						    $exist = true;
							break;
						}

					}
					if($exist == false)
						echo "<h1>vous n'etes pas enregistrer :</h1>"." <a href ='index.php'><input type='submit' value='retour'</a>";

					else{
						if($selected_val == "etudiant")
							header('Location: home.php'); 
							
						else
							header('Location: homeadmin.php'); 
							 	
					}

		}
		else 
				echo 'vous avez rien rentrer'.'<br>' ; 
		
        
    }
        fclose($f);
		
	?>