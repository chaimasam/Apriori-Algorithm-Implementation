 <?php 
include('../db.php'); 
 $statement = $bdd->prepare(
   "UPDATE reseau 
   SET   NomReseau= :NomReseau  WHERE Id_reseau = :Id_reseau
   "
  );
 $statement->bindParam(':NomReseau',$_POST["NomReseau"] );

 $statement->bindParam(':Id_reseau', $_POST["Id_reseau"]);
  $statement = $statement->execute();
 header("location:aff.php");
  ?>