<?php
 include('../db.php'); 

  
    $statement = $bdd->prepare("
   INSERT INTO voie (Nom_voie,CoordonneeX,CoordonneeY,Id_reseau) 
   VALUES ( :Nom_voie,:CoordonneeX, :CoordonneeY,:Id_reseau)
  ");
      $nv=$_POST["Nom_voie"];
      $cx=$_POST["CoordonneeX"];
      $cy= $_POST["CoordonneeY"];
      $idr=$_POST["Id_reseau"];
      $id=$_POST["Id_boulevard"];
     $statement->bindParam(':Nom_voie', $_POST["Nom_voie"]);
     $statement->bindParam(':CoordonneeX',$_POST["CoordonneeX"] );
      $statement->bindParam(':CoordonneeY', $_POST["CoordonneeY"]);
     $statement->bindParam(':Id_reseau',$_POST["Id_reseau"] );
 $statement = $statement->execute();
    $donn =   $bdd->query("
    select max(Id_voie) as id from voie
    ");
    $id_voie = $donn->fetch();
   
  $statement = $bdd->prepare("
   INSERT INTO boulevard (Id_voie,Id_boulevard,Nom_voie,CoordonneeX,CoordonneeY,Id_reseau) 
   VALUES (:Id_voie,:Id,:Nom_voie,:CoordonneeX, :CoordonneeY,:Id_reseau)
  ");

   
$statement->bindParam(':CoordonneeX',$cx);
 $statement->bindParam(':Id',$id );
 $statement->bindParam(':Id_reseau',$idr );
 $statement->bindParam(':Id_voie',$id_voie['id'] );
 $statement->bindParam(':CoordonneeY',$cy);
 $statement->bindParam(':Nom_voie',$nv);
  $statement = $statement->execute();
//echo $id;
 header("location:aff.php");

  if(!empty($result))
  {
   echo 'Data Inserted';
  }
 

 

?>