function myFunction(){
  var x = document.getElementById("nombre");
  N = x.value;
  var htmlcode = '';
  if(N<5)
    for(i=0;i<N;i++){
      htmlcode = htmlcode + "  <div><br><b>vehicule N :"+(i+1)+"</b><br><br><b>information vihécule</b> <div style=\"margin:10px;\"> <div class=\"form-input\" >"+
      "<label for=\"matricule\">matricule</label>"+
      "<input name=\"matricule\" class=\"form-control\"  placeholder=\"Min. 3 caractères\" required=\"required\" type=\"text\" />"
    +"</div>"
      + "  <div class=\"form-input\">"+
      "<label for=\"type\">type</label>"+
      "<input name=\"type_v\" class=\"form-control\"  placeholder=\"Min. 3 caractères\" required=\"required\" type=\"text\" />"
    +"</div>"
    + "  <div class=\"form-input\">"+
      "<label for=\"marque\">marque</label>"+
      "<input name=\"marque\" class=\"form-control\"  placeholder=\"Min. 3 caractères\" required=\"required\" type=\"text\" />"
    +"</div>"
    + "  <div class=\"form-input\">"+
      "<label for=\"etat\">etat mecanique</label>"+
     "<input name=\"etat\" class=\"form-control\"  placeholder=\"Min. 3 caractères\" required=\"required\" type=\"text\" />"
    +"</div><br>"
     + " <b>conducteur</b> <div style=\"margin:10px;\"> <div class=\"form-input\">"+
      "<label for=\"cin\">CIN</label>"+
      "<input name=\"cin\" class=\"form-control\"  placeholder=\"Min. 3 caractères\" required=\"required\" type=\"text\" />"
    +"</div>"
    + "  <div class=\"form-input\">"+
      "<label for=\"nom\">nom</label>"+
      "<input name=\"nom\" class=\"form-control\"  placeholder=\"Min. 3 caractères\" required=\"required\" type=\"text\" />"
    +"</div>"
    + "  <div class=\"form-input\">"+
      "<label for=\"prenom\">prenom</label>"+
      "<input name=\"prenom\" class=\"form-control\"  placeholder=\"Min. 3 caractères\" required=\"required\" type=\"text\" />"
    +"</div>"
    + "  <div class=\"form-input\">"+
    "<label for=\"permis\">type permis</label>"+
      "<input name=\"permis\" class=\"form-control\"  placeholder=\"Min. 3 caractères\" required=\"required\" type=\"text\" />"
    +"</div></br>"
    + "  <div class=\"form-input\">"
     + "<input name=\"Gendre\" value=\"homme\" type=\"radio\" />"
      +"homme"

     + "<input name=\"Gendre\" type=\"radio\" value=\"femme\" />"
      +"femme"

    +"</div>"
    +    "   <div class=\"form-group\">"
    +"<label for=\"etat_cond\">Etat:</label>"
    +"<select class=\"form-control\" name=\"etat_cond\" >"  
    + " <option value = \"normale\">normale</option>"
    + " <option value = \"ivre\">ivre</option>"
    + " <option  value = \"drogué\">drogué</option>"
    +"</select>"
    +"</div>"
    + "  <div class=\"form-input\">"+
      "<label for=\"age\">age</label>"+
      "<input name=\"age\" class=\"form-control\"  placeholder=\"Age  entre 18 et 99\" required=\"required\" type=\"text\" />"
    +"</div></div></div>"
    }
    document.getElementById("vehicule").innerHTML = htmlcode;

  }



















/*<script type="application/x-javascript">
  $(document).ready(function(){ //Debut de JQuery
 
 /*
 * Initialisation
 *//*
  var taille = 1;
   
  
   
   // je crée un evenement blur sur mes element nom et prenom
   $("form input#nom, form input#prenom").blur(function(){
     
     // je stocke mon element courant dans une variable
     var elt = $(this);
     
     if(elt.val().length <= 3){
       
       elt.css({
         "border": "1px solid red"
       });
       
     }else{
       
        elt.css({
         "border": "1px solid green"
        });
       
     }
   });
   
   /* 
     Exercice 1 : Controller à la perte de focus le champs code postal
    pour qu'il y ait 5 chiffres: Vert si c'est bon , rouge si ce n'est pas bon
    *//*
   $("form #cp").blur(function(){
     var elt= $(this);
     if(elt.val().length >= 5){
       elt.css({
         "border": "2px solid red"
       });
     }
     else{
        elt.css({
         "border": "2px solid green"
       }); 
     }
     
   });
   
     /* 
     Exercice 2 : Ajouter un controle quand on quitte  le focus sur le champs nom ou prenom que le nom soit différent du prénom. 
     SI le nom est égal au prénom
     mettre une bordure orange
    *//*
   $("form input#nom,form input#prenom").blur(function(){
     var elt = $(this);
     console.log(elt.val());
     
     if(elt.val().length <= 3){
       $("form input#nom,form input#prenom").css({
         "border": "1px solid red"
       });
       
     }else if($("#nom").val() == $("#prenom").val()){
        $("form input#nom,form input#prenom").css({
         "border": "1px solid orange"
       });
       
     }else{
        $("form input#nom,form input#prenom").css({
         "border": "1px solid green"
       });
     }
     
   }); 
     
   
   /* 
       Exercice 3 : Ajouter un controle quand on quitte le champs telephone qu'il y ait 10 chiffres
     *//*
   
   $('#telephone').blur(function(){
     var elt = $(this);
     
     if(elt.val().length < 10){
       elt.css({
         "border": "1px solid red"
       });
     }else{
       elt.css({
         "border": "1px solid red"
       });
     }
     
   });
   
   
    /* 
       Exercice 4 : Controller si la description quand je tape
       sur le clavier avec l'evenement keyyup
       + SI la description fait <10 caractees: bordure rouge
       + SI la description est comprise entre 10 et 20: bordure orange
       + Si la description est 20 et 30 caractères: bordure jaune
       + SI la description est supérieur à 30 caractères: bordure verte
     *//*
   
   
   $('form textarea#description').keyup(function(){
     
     var longueurelt = $(this).val().length;
     
     if(longueurelt < 10){
       $(this).css({
         "border": "1px solid red"
       });
     }else if(longueurelt >= 10 && longueurelt < 20){
       $(this).css({
         "border": "1px solid orange"
       });
     }else if(longueurelt >= 20 && longueurelt < 30){
       $(this).css({
         "border": "1px solid yellow"
       });
     }else{
       $(this).css({
         "border": "1px solid green"
       });
     }
     
   });
     
     /* 
       Exercice 5: Controller quand je tappe  la confirmation de mon mot de passe (evenement  keyup) que cette confirmation soit égal à mon mot de passe.
     *//*
   
   $('input:password').keyup(function(){
     
     var elt = $(this);
  /*    console.log(elt.val()); */
     /*if($("form input#mdp").val() == $("form input#confmdp").val()){
       elt.css({
         "border": "1px solid red"
       }); 
     }else{
       elt.css({
         "border": "1px solid green"
       });
     }
     
   });
   
   /*
   * Exercice 6: Controller quand je tape mon age( evenemnt keyup) que mon age soit compris  entre 18 et 99 ans
   *//*
   
   
   $('form input#age').keyup(function(){
     var age = $(this).val();
     
     if(age >= 18 && age < 99){
       $('form input#age').css({
         "border": "1px solid green"
       });      
     }
     else{
         $('form input#age').css({
         "border": "1px solid red"
       });
     }
   });
   
     /*
     * Exercice 7: Controller quand je quite mon champs username qui soit différent du nom et du prénom
     *//*
   
   $("input#username,input#nom,input#prenom").blur(function(){
     var username = $("#username");
     var nom = $("#nom");
     var prenom = $("#prenom");
     
     if(username.val() == nom.val() || username.val() == prenom.val()){
       
       $('#nom,#prenom,#username').css({
         "border": "1px solid red"
       });
         
     }else{
        $('#nom,#prenom,#username').css({
         "border": "1px solid green"
       });
     }
     
   });
   
   
   
   
   
    /*
     * Exercice 8: Controller quand je clique sur mon boutton crée un compte que
      j'ai coché au moin 1 sexe (Fille ou Garcon ou Indifférent)
     *//*
   
   $("form button#submit").click(function(){
     
     // 2eme méthode
     // length sur un element
     // c'est pour compter le nb d'element présent dans ma page
     if($("form input[name=sexe]:checked").length < 1 ){
       
     }
     
     //1er methode
     if($("#garcon").is(":checked") 
       || $("#fille").is(":checked")
       || $("#indifferent").is(":checked")
       ){
       
       $("[name='sexe'] + label").css({
         "color": "1px solid red"
       });
       
       
     }else{
        
       $("[name='sexe'] + label").css({
         "color": "1px solid green"
       });
       
     }
     
   });
   
    /*
     * Exercice 9: Controller quand je clique sur mon boutton de vérifier si j'ai au moins 
     * 2 cases à cocher cochées dans mon formulaire
     *//*
     $('button#submit').click(function(){
       
      var elt = $(this);
       
       if($(':checkbox:checked').length < 2){
         alert('2 cases doivent etre cochées');
       }
       
     });
   
   
    /*
     * Exercice 10: Controller quand je clique sur mon boutton de vérifier si j'ai ma case
     * a cocher C.G.U. est bien valider
     */
     /*$("form button#submit").click(function(){
       
       
       // 2 methode:  $("form input[name='cgu']").is(':checked') == false
       
       if($("form input[name='cgu']:checked").length < 1 ){
         alert("Veuillez accepter les conditions générales d'utilisation");
       }
       
     });
     
   
      
    /*
     * Exercice 11: Ajouter un bouton "+" et un bouton "-" sur la description pour         augmenter ou diminuer la taille de police de saisie des contenus
     */
  
 
   /*
   $("#more, #less").click(function(){
     
     var elt = $(this);
     
     if(elt.attr('id') == "more"){
       taille++;
     }else{
       taille--;
     }
     
     $('textarea').css({
       'font-size':  taille + "em" 
     })
     
   })
   
   
   /*
   *  Exercice 12: Controller quand je tappe une url de photo, cela m'affiche l'apercu
   *  de l'image en dessous ( Il existe une fonction attr() en Jquery)
   */
   
   /*$('#photo').keyup(function(){
     var elt = $(this);
     
     $('form img#photoPreview').attr('src', elt.val());
     
     
   });
   
   /*
   * Exercice 13:
   * Modifier le compteur de caractères pour la description (par décrémentation) quand je tape dans la zone de saisie
   * Indice: Fonction text() ou fonction html()
   */
   /*$('textarea#description').keyup(function(){
     var nbcaractere = $.trim($(this).val()).length;
     var total = 300 - nbcaractere;
     
     // $.trim() est une fonction qui permet de supprimer les espaces
     // au debut et a la fin de chaine de caractères
     
     if(total == 0){
       $('textarea#description').attr("disabled", "disabled")
     }
     
     if(total < 300 && total > 200){
           $("span.help-block b").html("<span class='fa fa-exclamation-triangle'></span>"+total); 
     }else if(total < 200 && total > 100){
       $("span.help-block b").html("<span class='fa fa-bell'></span>"+total);
     }else{
       $("span.help-block b").html(total);
     }
     
     
   });
   
   /*
   * Exercice 14:
   * Générer 2 nombre aléatoire pour le capcha et l'afficher a coté du champ Capcha lors du chargement de la page
   (fonction text() pour modifier du texte sur un element )
   */
   
   /*
   * Exercice 15: Ajouter une checkbox "Voir le mot de passe en claire" en HTML et quand je clique su cette checkbox
   * le mot de passe est révélé en claire (fonction attr() pour modifier un attribut)
   */
   
   /*
   * Exercice 16:
   * Lors du clique du bouton "Créer un compte", vérifier la saisie du CAPCHA que se soit el resultat de la somme
   * des 2 chiffres généré aléatoirement
   * Indice: Fonction text() ou fonction html()
   */
   
   /*
   * Exercice 17:
   * Créer une barre de progression (Exemple: https://getbootstrap.com/components/#progress)
   * qui augmente de taille selon la longeur du mot de passe quand je saisi mon mot  de passe
   */
   
  /* 
 }); //fin de JQuery
  </script> 
*/