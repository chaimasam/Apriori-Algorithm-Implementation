<?php

$username = 'root';
$password = '';
$bdd = new PDO( 'mysql:host=localhost;dbname=database', $username, $password );

?>