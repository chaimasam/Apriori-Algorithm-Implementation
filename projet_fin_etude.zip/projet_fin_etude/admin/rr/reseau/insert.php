<?php
 include('../db.php'); 
  $statement = $bdd->prepare("
   INSERT INTO reseau (Id_reseau,NomReseau) 
   VALUES (:Id_reseau,:NomReseau)
  ");
  $statement->bindParam(':NomReseau',$_POST["NomReseau"] );
 $statement->bindParam(':Id_reseau',$_POST["Id_reseau"] );

  $statement = $statement->execute();
 header("location:aff.php");
  if(!empty($result))
  {
   echo 'Data Inserted';
  }
 

 

?>