 <?php 
include('../db.php'); 
 $statement = $bdd->prepare(
   "UPDATE boulevard 
   SET  CoordonneeX = :CoordonneeX, CoordonneeY = :CoordonneeY , Nom_voie= :Nom_voie
   WHERE Id_boulevard = :Id
   "
  );
  $statement->bindParam(':CoordonneeX',$_POST["CoordonneeX"] );
 $statement->bindParam(':Id',$_POST["Id_boulevard"] );
 $statement->bindParam(':CoordonneeY', $_POST["CoordonneeY"]);
 $statement->bindParam(':Nom_voie', $_POST["Nom_voie"]);
  $statement = $statement->execute();
$statement = $bdd->prepare(
   "UPDATE voie 
   SET  CoordonneeX = :CoordonneeX, CoordonneeY = :CoordonneeY , Nom_voie= :Nom_voie
   WHERE Id_voie = :Id_voie
   "
  );
 $statement->bindParam(':CoordonneeX',$_POST["CoordonneeX"] );
 $statement->bindParam(':Id_voie',$_POST["Id_voie"] );
 $statement->bindParam(':CoordonneeY', $_POST["CoordonneeY"]);
 $statement->bindParam(':Nom_voie', $_POST["Nom_voie"]);
  $statement = $statement->execute();
 header("location:aff.php");
  ?>