 <?php 
include('../db.php'); 
 $statement = $bdd->prepare(
   "UPDATE rondpoint 
   SET  CoordonneeX = :CoordonneeX, CoordonneeY = :CoordonneeY , NomIntersection= :NomIntersection
   WHERE Id_RondPoint = :Id
   "
  );
  $statement->bindParam(':CoordonneeX',$_POST["CoordonneeX"] );
 $statement->bindParam(':Id',$_POST["Id_RondPoint"] );
 $statement->bindParam(':CoordonneeY', $_POST["CoordonneeY"]);
 $statement->bindParam(':NomIntersection', $_POST["NomIntersection"]);
  $statement = $statement->execute();
$statement = $bdd->prepare(
   "UPDATE grapheintersection
   SET  CoordonneeX = :CoordonneeX, CoordonneeY = :CoordonneeY , NomIntersection= :NomIntersection
   WHERE Id_intersection = :Id_intersection
   "
  );
 $statement->bindParam(':CoordonneeX',$_POST["CoordonneeX"] );
 $statement->bindParam(':Id_intersection',$_POST["Id_intersection"] );
 $statement->bindParam(':CoordonneeY', $_POST["CoordonneeY"]);
 $statement->bindParam(':NomIntersection', $_POST["NomIntersection"]);
  $statement = $statement->execute();
 header("location:aff.php");
  ?>