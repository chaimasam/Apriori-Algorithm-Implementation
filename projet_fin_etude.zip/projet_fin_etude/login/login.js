function login(){
    x = document.querySelectorAll(".user-form");
    name = x[0].value;
    psw = x[1].value;
 
    select = document.getElementById("mdb-select");
    choice = select.options[select.selectedIndex].text;
  

     /*   $.post('loginpost.php',{username:name,password:psw,type:choice},
            function(data){
                if(data == "Admin")   document.location.href = 'www.mozilla.org';
                else if (data == "Policier") document.location.href = 'police.php'; 
                    else if (data == "Décideur")    document.location.href = 'decideur.php';
                        else $("#erreur_cnx").html("les donnees incorrectes")
                        .css({"font-size" : "20px"})
                        .css( { "color" : "red" });
       }*/
     /* $.ajax({
      url:"loginpost.php",
      method:"POST",
      data : {username:name,password:psw,type:choice},
      success:function(data)
      {
      	alert(data);
       }
    }); */
     $.ajax({url:"loginpost.php",
      method:"POST",
      data : {username:name,password:psw,type:choice},
      success:function(data)
      {
        if(data == "Admin")   document.location.href = '../index1.php';
                else if (data == "Policier") document.location.href = '../policier/index.php'; 
                    else if (data == "Décideur")    document.location.href = 'decideur.php';
                        else $("#erreur_cnx").html("les donnees incorrectes")
                        .css({"font-size" : "20px"})
                        .css( { "color" : "red" });
       }
});
}
