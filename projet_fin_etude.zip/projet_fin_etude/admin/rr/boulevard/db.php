<?php

$username = 'root';
$password = '';
$bdd = new PDO( 'mysql:host=localhost;dbname=reseauroutier', $username, $password );

?>