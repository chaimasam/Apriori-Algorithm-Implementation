<?php
include('db.php');
include('function.php');
if(isset($_POST["user_id"]))
{
 $output = array();
 $statement = $bdd->prepare(
  "SELECT * FROM police 
  WHERE id = '".$_POST["user_id"]."' 
  LIMIT 1"
 );
 $statement->execute();
 $result = $statement->fetchAll();
 foreach($result as $row)
 {
  $output["id_lieu"] = $_POST["id_lieu"],
    $output["Id_voie"] = $_POST["Id_voie"],
    $output["CoordonneeX"] = $_POST["CoordonneeX"],
    $output["CoordonneeY"} = $_POST["CoordonneeY"],
   $output["Id_reseau"]   = $_POST["Id_reseau"],
    $output["Id"]   = $_POST["user_id"]
  
 }
 echo json_encode($output);
}
?>
   