<?php
	try{
		$bdd = new PDO('mysql:host=localhost;dbname=reseauroutier', 'root', '');
	}catch (Exception $e){
		
		die('Erreur : ' . $e->getMessage());
	}
	$reponse = $bdd->query('SELECT * FROM boulevard');
	$i =0;
	while ($donnees = $reponse->fetch())
	{
		if($donnees['valide'] == $_SESSION['valide']){
			echo "<tr  class = \"ligne$i\">
				<td style=\"width: 8%;\"class = \"num\">
					".$donnees['num_aprojet']."
				</td>
				<td class = \"name\" style=\"width: 18%;\">
					".$donnees['name']."
				</td>
				<td class = \"CNE\">
					".$donnees['CNE']."
				</td>
				<td class = \"CIN\">
					".$donnees['CIN']."
				</td>
				<td  class = \"naissace\">
					".$donnees['date_naissance']."
				</td>
				<td class = \"gmail\">
					".$donnees['gmail']."
				</td>
				<td class = \"tel\">
					".$donnees['tel']."
				</td>
				<td class = \"adress\">
					".$donnees['adress']."
				</td>";
			if ($_SESSION['valide'] == 1) {
				echo "<td class=\"button\" colspan =\"2\"  style=\"border-color: white;\">
					<button class=\"btn Edit\" \" style=\"margin-right : 10px;\"
					onclick =\"modifier($i,".$donnees['num_aprojet'].", '".$donnees['name']."', '".$donnees['CNE']."', '".$donnees['CIN']."','"
						.$donnees['date_naissance']."','".$donnees['gmail']."', '".$donnees['tel']."', '".$donnees['adress']."');\"	> Edit </button>
					<button class=\"btn Delete\" onclick = \"courbeille(".$donnees['num_aprojet'].",0,1);\"> Delete </button>
					</td>
					</tr>" ;
				}
			else{
				echo "<td class=\"button\" style=\"border-color: white;\">
					<button class=\"btn Restaurer\" onclick = \"courbeille(".$donnees['num_aprojet'].",1,1);\"> Restaurer </button>
					<button class=\"btn Delete\" onclick = \"supprimer(".$donnees['num_aprojet'].",1);\"> Delete </button></td>";
			}
			$i++;
		}
	}	
?>