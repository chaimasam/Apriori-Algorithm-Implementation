<?php
include('../admin/db.php');
session_start();
	$exist =false;
	if( isset($_POST["username"]) && isset($_POST["password"]))
	{
		$nom=$_POST["username"];
		$code=$_POST["password"];
		//$code = md5($code);

		if(!empty($nom) && !empty($code) )
		{
			  // Storing Selected Value In Variable
			if($_POST['type'] == "Admin"){
				$req = $bdd->prepare('select count(*) as existe FROM admin WHERE username =
				? AND password = ?');	
			}
			elseif ($_POST['type'] == "Policier") {
				$req = $bdd->prepare('select count(*) as existe FROM police WHERE username =
				? AND password = ?');
			}
			elseif ($_POST['type'] == "Décideur") {
				$req = $bdd->prepare('select count(*) as existe FROM decideur WHERE username =
				? AND password = ?');
			}
	
			$req->execute(array( $_POST['username'], $_POST['password'] ));
			if($req->fetch()['existe'] == 1){
				$_SESSION['name'] =  $_POST['username'];
				$_SESSION['password'] = $_POST['password'];
				$_SESSION['type'] = $_POST['type'];
				echo $_POST['type'];
			}
		}
	}
	else 
		echo 'vous avez rien rentrer'.'<br>' ; 
		
        
    	
?>